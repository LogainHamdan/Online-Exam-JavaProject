/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author pc
 */
public class Exam extends Course{

   private String id;
   private boolean active;
    private double period;
    private Question q1;
    private Question q2; 
    

    
    public Exam() {

    }

    public Exam(boolean active, Question q1, Question q2) {
       this.q1=q1;
       this.q2=q2;
       this.active=active;
    }

    public String getId() {
        return id;
    }

    public Question getQ1() {
        return q1;
    }

    public void setQ(Question q1) {
        this.q1 = q1;
    }

    public Timer getTimer() {
        return timer;
    }

    public void setTimer(Timer timer) {
        this.timer = timer;
    }

    public int getSeconds() {
        return seconds;
    }

    public void setSeconds(int seconds) {
        this.seconds = seconds;
    }

    public Timer getMyTimer() {
        return myTimer;
    }

    public Question getQ2() {
        return q2;
    }

    public void setQ2(Question q2) {
        this.q2 = q2;
    }

    public void setMyTimer(Timer myTimer) {
        this.myTimer = myTimer;
    }

    public TimerTask getTask() {
        return task;
    }

    public void setTask(TimerTask task) {
        this.task = task;
    }

    public boolean isActive() {
        return active;
    }

    public double getPeriod() {
        return period;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public void setPeriod(double period) {
        this.period = period;
    }
    
    
   
    Timer timer = new Timer();

    int seconds = 0;
    Timer myTimer = new Timer();
    TimerTask task = new TimerTask() {
        @Override
        public void run() {
           seconds++;
        }
    };


    public void start() {
        myTimer.scheduleAtFixedRate(task, 50, 50);

    }

    Object getQ() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
