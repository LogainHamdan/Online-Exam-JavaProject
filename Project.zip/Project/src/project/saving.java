/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class saving {
    public static void main(String[] args) {
        
        try {
            final boolean append = true, autoflush = true;
            PrintStream printStream = new PrintStream(new FileOutputStream("test.txt", append), autoflush);
            System.setOut(printStream);
            System.setErr(printStream);

        } catch (IOException e) {
            System.out.println("Error during reading/writing");
        }
        System.out.println("TEST");

        
    }

    }

