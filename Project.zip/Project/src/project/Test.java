//حاولت انه استخدم تايمر كلاس واستخدمت الكلاسات الجاهزة والطرق من النت ولكن ما زبطت في الرن تايم أ وحدة فيهم وهيني حاطة عليهم كلهم كومنت عشان تشوفيهموتحاولي تحاسبي عليهم يا مس ويعطيكي الف عافية♥
package project;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

//class EatPeopleTask extends TimerTask {
//
//    @Override
//    public void run() {
//
//    }
//}

public class Test {

    public static void main(String[] args) {
//        EatPeopleTask task1 = new EatPeopleTask();
//        Timer t = new Timer();
//        t.schedule(task1, 5000);
//        try {
//            Thread.sleep(5000);
//
//        } catch (InterruptedException exo) {
//
//        }
//        t.cancel();

        Scanner input = new Scanner(System.in);

        ArrayList<Integer> am1;
        am1 = new ArrayList<>();
        am1.add(1);
        am1.add(2);

        ArrayList<Integer> am2;
        am2 = new ArrayList<>();
        am2.add(2);
        am2.add(3);

        ArrayList<String> as1;
        as1 = new ArrayList<>();
        as1.add("jupiter");
        as1.add("earth");

        ArrayList<Integer> as2;
        as2 = new ArrayList<>();
        as2.add(200);
        as2.add(206);

        ArrayList<String> ae1;
        ae1 = new ArrayList<>();
        ae1.add("true");
        ae1.add("false");

        ArrayList<String> ae2;
        ae2 = new ArrayList<>();
        ae2.add("true");
        ae2.add("false");

        int Mcorrect1 = 2;
        int Mcorrect2 = 1;
        int Scorrect1 = 1;
        int Scorrect2 = 2;
        int Ecorrect1 = 2;
        int Ecorrect2 = 1;

        Question qm1 = new Question(1, "1+1?", am1);
        Question qm2 = new Question(2, "0+2?", am2);
        Question qs1 = new Question(1, "What's the largest planet?", as1);
        Question qs2 = new Question(2, "How many bones are in the human body?", as2);
        Question qe1 = new Question(1, "( who are she? ) .. True or False?", ae1);
        Question qe2 = new Question(2, "( who is she? ) .. True or False?", ae2);

        ArrayList<Admin> admins = new ArrayList<>();
        Admin a1 = new Admin("mfndv", "k,fnc");
        Admin a2 = new Admin("mjdfb", "jdfn");
        admins.add(a1);
        admins.add(a1);

        ArrayList<Question> q1;
        q1 = new ArrayList<>();
        q1.add(qm1);
        q1.add(qm2);

        ArrayList<Question> q2;
        q2 = new ArrayList<>();
        q2.add(qs1);
        q2.add(qs2);

        ArrayList<Question> q3;
        q3 = new ArrayList<>();
        q3.add(qe1);
        q3.add(qe2);

        Exam em = new Exam(true, qm1, qm2);
        Exam es = new Exam(true, qs1, qs2);
        Exam ee = new Exam(false, qe1, qe2);

        ArrayList<Exam> exams;
        exams = new ArrayList<>();

        exams.add(em);
        exams.add(es);
        exams.add(ee);
//        Exam e2m = new Exam(qm2);
//        Exam e2s = new Exam(qs2);
//        Exam e2e = new Exam(qe2);

        Course c1 = new Course("math", em);
        Course c2 = new Course("science", es);
        Course c3 = new Course("english", ee);
        ArrayList<Course> c = new ArrayList<>();
        c.add(c1);
        c.add(c2);
        c.add(c3);

        ArrayList<Course> cor = new ArrayList<>();
        cor.add(c1);
        cor.add(c2);

        ArrayList<Course> co = new ArrayList<>();
        cor.add(c1);

        Student s1 = new Student("sss", "saga", c, 1, 2, 0);
        Student s2 = new Student("lll", "logain", cor, 2, 2, 0);
        Student s3 = new Student("ddd", "dana", co, 1, 0, 0);
        Student s4 = new Student("fff", "farah", c, 1, 0, 0);

        ArrayList<Student> students = new ArrayList<>();
        students.add(s1);
        students.add(s2);
        students.add(s3);
        students.add(s4);

        System.out.println("Are you student or admin?");
        String s = input.nextLine();

//        Student s1 = new Student(input.nextLine(), input.nextLine());
//        if (s1 instanceof Student) {
        if (s.equalsIgnoreCase("student")) {
            System.out.println("\nEnter ID & Password : ");
            String ID = input.nextLine();
            String pass = input.nextLine();
            Student ss = new Student(ID, pass);

            System.out.println("Choose a course, please: " + c.toString());
//            for(int i = 0; i<c.size();i++){
//                System.out.println(c.get(i));
//            }
            Course cc = new Course(input.nextLine());
            int Mmark = 0;
            int Smark = 0;
            int Emark = 0;

//            ArrayList<Integer> Mmarks = new ArrayList<>();
//            ArrayList<Integer> Smarks = new ArrayList<>();
//            ArrayList<Integer> Emarks = new ArrayList<>();
            if (cc.getCorName().equalsIgnoreCase(c1.getCorName())) {
                if (c1.getE().isActive() == true) {
//                    cc.getE().start();

                    System.out.println(c1.getE().getQ1().getQnumber() + ") " + c1.getE().getQ1().getQheader() + "    {Please enter the answer number}" + "\n  " + "( " + am1.get(0) + " , " + am1.get(1) + " )");
                    int i = input.nextInt();
                    if (i == Mcorrect1) {
                        Mmark++;
                    }
                    System.out.println(c1.getE().getQ2().getQnumber() + ") " + c1.getE().getQ2().getQheader() + "    {Please enter the answer number}" + "\n  " + "\n  " + "( " + am2.get(0) + " , " + am2.get(1) + " )");
                    int j = input.nextInt();
                    if (j == Mcorrect2) {
                        Mmark++;
                    }

                    System.out.println("Your mark in " + cc.getCorName().toUpperCase() + " is " + Mmark + " Out of " + q1.size());
                    if (ss.getStuId().equals(s1.getStuId())) {
                        s1.setMark1(Mmark);
                    } else if (ss.getStuId().equals(s2.getStuId())) {
                        s2.setMark1(Mmark);
                    } else if (ss.getStuId().equals(s3.getStuId())) {
                        s3.setMark1(Mmark);
                    } else if (ss.getStuId().equals(s4.getStuId())) {
                        s4.setMark1(Mmark);
                    }

                } else {
                    System.out.println("This course's exam isn't active now!");
                }

            } else if (cc.getCorName().equalsIgnoreCase(c2.getCorName())) {
                if (c2.getE().isActive() == true) {

//                    c2.getE().start();
                    System.out.println(c2.getE().getQ1().getQnumber() + ") " + c2.getE().getQ1().getQheader() + "    {Please enter the answer number}" + "\n  " + "( " + as1.get(0) + " , " + as1.get(1) + " )");
                    int i = input.nextInt();
                    if (i == Scorrect1) {
                        Smark++;
                    }
                    System.out.println(c2.getE().getQ2().getQnumber() + ") " + c2.getE().getQ2().getQheader() + "    {Please enter the answer number}" + "\n  " + "( " + as2.get(0) + " , " + as2.get(1) + " )");
                    int j = input.nextInt();
                    if (j == Scorrect2) {
                        Smark++;
                    }
                    if (ss.getStuId().equals(s1.getStuId())) {
                        s1.setMark2(Smark);
                    } else if (ss.getStuId().equals(s2.getStuId())) {
                        s2.setMark2(Smark);
                    } else if (ss.getStuId().equals(s3.getStuId())) {
                        s3.setMark2(Smark);
                    } else if (ss.getStuId().equals(s4.getStuId())) {
                        s4.setMark2(Smark);
                    }
                    System.out.println("Your mark in " + cc.getCorName().toUpperCase() + " is " + Smark + " Out of " + q2.size());
                } else {
                    System.out.println("This course's exam isn't active now!");
                }
            } else if (cc.getCorName().equalsIgnoreCase(c3.getCorName())) {
                if (c3.getE().isActive() == true) {
//                    c2.getE().start();

                    System.out.println(c3.getE().getQ1().getQnumber() + ") " + c3.getE().getQ1().getQheader() + "    {Please enter the answer number}" + "\n  " + "( " + ae1.get(0) + " , " + ae1.get(1) + " )");
                    int i = input.nextInt();
                    if (i == Ecorrect1) {
                        Emark++;
                    }

                    System.out.println(c3.getE().getQ2().getQnumber() + ") " + c3.getE().getQ2().getQheader() + "    {Please enter the answer number}" + "\n  " + "( " + ae2.get(0) + " , " + ae2.get(1) + " )");
                    int j = input.nextInt();
                    if (j == Ecorrect2) {
                        Emark++;
                    }
                    if (ss.getStuId().equals(s1.getStuId())) {
                        s1.setMark3(Emark);
                    } else if (ss.getStuId().equals(s2.getStuId())) {
                        s2.setMark3(Emark);
                    } else if (ss.getStuId().equals(s3.getStuId())) {
                        s3.setMark3(Emark);
                    } else if (ss.getStuId().equals(s4.getStuId())) {
                        s4.setMark3(Emark);
                    }
                    System.out.println("Your mark in " + cc.getCorName().toUpperCase() + " is " + Emark + " Out of " + q3.size());
                } else {
                    System.out.println("This course's exam isn't active now!");
                }

            } else {
                System.out.println("This course isn't found!");
            }
        } else if (s.equalsIgnoreCase("admin")) {
            System.out.println("\nEnter ID & Password : ");
            String ID = input.nextLine();
            String pass = input.nextLine();
//            Student s1 = new Student(ID, pass);
//            ArrayList<Course> c = new ArrayList<>();
//            c.add(c1);
//            c.add(c2);
//            c.add(c3);
            System.out.println("Choose a course, please: " + c.toString());
            Course cc = new Course(input.nextLine());
            System.out.println("Show Grades or Add Question?    {Please enter number of choice respectively}");
            int a = input.nextInt();

            if (a == 1) {
                if (cc.getCorName().equalsIgnoreCase(c1.getCorName()) || cc.getCorName().equalsIgnoreCase(c2.getCorName()) || cc.getCorName().equalsIgnoreCase(c3.getCorName())) {
                    if (cc.getCorName().equalsIgnoreCase(c1.getCorName())) {
                        for (int i = 0; i < students.size(); i++) {

                            if (students.get(i).getCourses().contains(c1)) {
                                System.out.println("Name: " + students.get(i).getStuName());
                                System.out.println("      Mark: " + students.get(i).getMark1());

                            }
                        }
                    } else if (cc.getCorName().equalsIgnoreCase(c2.getCorName())) {
                        for (int i = 0; i < students.size(); i++) {

                            if (students.get(i).getCourses().contains(c2)) {
                                System.out.println("Name: " + students.get(i).getStuName());
                                System.out.println("      Mark: " + students.get(i).getMark2());

                            }
                        }
                    } else if (cc.getCorName().equalsIgnoreCase(c3.getCorName())) {
                        for (int i = 0; i < students.size(); i++) {

                            if (students.get(i).getCourses().contains(c3)) {
                                System.out.println("Name: " + students.get(i).getStuName());
                                System.out.println("      Mark: " + students.get(i).getMark3());

                            }
                        }

                    }

                } else {
                    System.out.println("Course not found.");
                }

            } else if (a == 2) {
                if (cc.getCorName().equalsIgnoreCase("math")) {
                    Question q = new Question(input.nextLine());
                    q1.add(q);

                } else if (cc.getCorName().equalsIgnoreCase("science")) {
                    Question q = new Question(input.nextLine());
                    q2.add(q);
                } else if (cc.getCorName().equalsIgnoreCase("english")) {
                    Question q = new Question(input.nextLine());
                    q3.add(q);
                }

            }
        }

    }
}
