/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

/**
 *
 * @author pc
 */
public class Course {

    private String Corid;
    private String Corname;
    private double mark;
    Exam e;

    public Course() {

    }

    public Course(String Corname) {
        this.Corname = Corname;

    }

    public Course(String Corname, Exam e) {
        this.e = e;
        this.Corname = Corname;

    }

    public String getCorid() {
        return Corid;
    }

    public void setCorid(String Corid) {
        this.Corid = Corid;
    }

    public String getCorname() {
        return Corname;
    }

    public void setCorname(String Corname) {
        this.Corname = Corname;
    }

    public Exam getE() {
        return e;
    }

    public void setE(Exam e) {
        this.e = e;
    }

    public Course(String Corid, String Corname) {
        this.Corid = Corid;
        this.Corname = Corname;
    }

    public String getCorId() {
        return Corid;
    }

    public String getCorName() {
        return Corname;
    }

    public double getMark() {
        return mark;
    }

    public void setCorId(String Corid) {
        this.Corid = Corid;
    }

    public void setCorName(String Corname) {
        this.Corname = Corname;
    }

    public void setMark(double mark) {
        this.mark = mark;
    }

    @Override
    public String toString() {
        return Corname ;
    }

   

}
