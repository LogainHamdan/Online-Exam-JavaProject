/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.ArrayList;

/**
 *
 * @author pc
 */
public class Student extends Course {

    private String Stuid;
    private String Stuname;
    private String password;
    private int mobile;
    private String email;
    private ArrayList<Course> courses;
    private double mark1;
     private double mark2;
      private double mark3;
    public Student() {

    }

    public Student(String Stuid, String password) {
        this.Stuid = Stuid;
        this.password = password;
    }

    public Student(String Stuid, String stuname, ArrayList<Course> a, double mark1,double mark2, double mark3) {
        this.mark1=mark1;
        this.mark2=mark2;
        this.mark3=mark3;
        this.Stuname = stuname;
        courses = a;

    }

    public String getStuId() {
        return Stuid;
    }

    public String getStuName() {
        return Stuname;
    }

    public String getPassword() {
        return password;
    }

    public int getMobile() {
        return mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setStuId(String Stuid) {
        this.Stuid = Stuid;
    }

    public void setStuName(String Stuname) {
        this.Stuname = Stuname;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setMobile(int mobile) {
        this.mobile = mobile;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getStuid() {
        return Stuid;
    }

    public void setStuid(String Stuid) {
        this.Stuid = Stuid;
    }

    public String getStuname() {
        return Stuname;
    }

    public void setStuname(String Stuname) {
        this.Stuname = Stuname;
    }

    public ArrayList<Course> getCourses() {
        return courses;
    }

    public void setCourses(ArrayList<Course> courses) {
        this.courses = courses;
    }

    public double getMark1() {
        return mark1;
    }

    public void setMark1(double mark1) {
        this.mark1 = mark1;
    }

    public double getMark2() {
        return mark2;
    }

    public void setMark2(double mark2) {
        this.mark2 = mark2;
    }

    public double getMark3() {
        return mark3;
    }

    public void setMark3(double mark3) {
        this.mark3 = mark3;
    }

}
