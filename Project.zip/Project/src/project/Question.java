/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.ArrayList;

/**
 *
 * @author pc
 */
public class Question {

    private String id;
    private int Qnumber;
    private String Qheader;
    private ArrayList ansewrs;
    private String correctAnswer;
    private double Qmark;

    public Question() {

    }

    public Question(String Qheader) {
        this.Qheader = Qheader;
    }

    public Question(int Qnumber, String Qheader, ArrayList answers) {
        this.Qheader = Qheader;
        this.Qnumber = Qnumber;
        this.ansewrs = answers;
    }

    public String getId() {
        return id;
    }

    public int getQnumber() {
        return Qnumber;
    }

    public String getQheader() {
        return Qheader;
    }

    public ArrayList<String> getAnsewrs() {
        return ansewrs;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public double getQmark() {
        return Qmark;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setQnumber(int Qnumber) {
        this.Qnumber = Qnumber;
    }

    public void setQheader(String Qheader) {
        this.Qheader = Qheader;
    }

    public void setAnsewrs(ArrayList<String> ansewrs) {
        this.ansewrs = ansewrs;
    }

    public void setCorrectAnswer(String correctAnswer) {
        this.correctAnswer = correctAnswer;
    }

    public void setQmark(double Qmark) {
        this.Qmark = Qmark;
    }

}
